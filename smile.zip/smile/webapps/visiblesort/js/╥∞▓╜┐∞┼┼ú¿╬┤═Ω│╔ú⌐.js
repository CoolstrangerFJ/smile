		
//		var mid = new Array();
//		var begin = new Array();
//		var end = new Array();
//		var now = 0;
//		var head = 0;
//		var tail = n-1;
//		var temp = 0;
//		var left = false, right = true;
//		var situation = false;
//		var 
//		begin[0]=0;end[0]=n-1;
//		var finish = false;
//		function quicksort(){
//			begin[now]=s;
//			end[now]=t;
//			if(situation == left){
//				while(rand[tail] >= rand[temp] && tail > head){tail--;}
//				if(tail > head){
//					swap(tail,temp);
//					temp=tail;
//					situation = !situation;
//					setTimeout(quicksort);
//				}
//			}else{
//				while(rand[head] <= rand[temp] && head < tail){head++;}
//				if(head < tail){
//					swap(head,temp);
//					temp = head;
//					situation = !situation;
//					setTimeout(quicksort);
//				}
//			}
//			if(head == tail){
//				if(begin[now]==end[now]){
//					alert("!!!");
//					rightarr();
//					situation = left;
//					setTimeout(quicksort);
//				}else{
////					alert("head==tail!");
//					mid[now]=temp;
//					now++;
//					leftarr();
//					situation = left;
//					setTimeout(quicksort);
//					
//				}
//			}
//		}
		
//		function leftarr(){
//			begin[now]=begin[now-1];
//			end[now]=mid[now-1];
//			head=begin[now];
//			tail=end[now];
//			temp = head;
//		}
//		
//		function rightarr(){
//			begin[now]=mid[now-1];
//			end[now]=end[now-1];
//			head=mid[now];
//			tail=end[now];
//			temp = head;
//		}
		
////		var step=0;
//		var choice = new Array();
//		choice[0]=0;
//		function recall(){
//			if(now>=0){
//				if(begin[now]==end[now]){
////					now--;
////					choice[now]++;
//					if(now > 0){
//						if(end[now]==end[now-1]){
//							now--;
//						}else{
//							rightarr();
//							
//						}
//					}
//				}
//				choice[now]++;
//				if(choice[now]==1){
//					begin[now+1]=begin[now];
//					end[now+1]=mid[now];
//					now++;
//					head=begin[now];
//					tail=end[now];
//					temp = head;
//					setTimeout(quicksort);
//				}
//				if(choice[now]==2){
//					begin[now+1]=mid[now];
//					end[now+1]=end[now];
//					now++;
//					head=mid[now];
//					tail=end[now];
//					temp = head;
//					setTimeout(quicksort);
//				}
////				if()
////				qs();
//				if(choice[now]>2){
//					now--;
//					setTimeout(quicksort);
//				}else{
//					if(begin[now]==end[now]){
//						
//					}else{
//						
//					}
//				}
//			}
//		}
